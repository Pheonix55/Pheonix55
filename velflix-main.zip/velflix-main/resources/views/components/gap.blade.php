<div class="w-full h-3" style="background-color: #222"></div>
